define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnBack **/
    AS_Button_db897196bdf8461ab49c8a1799fce673: function AS_Button_db897196bdf8461ab49c8a1799fce673(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmMenu");
        ntf.navigate();
    },
    /** onmapping defined for frmView **/
    AS_Form_d9a431afd8ff42d1b0e4c359ae975c6d: function AS_Form_d9a431afd8ff42d1b0e4c359ae975c6d(eventobject) {
        var self = this;
    }
});