define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnAdd **/
    AS_Button_bde167617dd84db795b86b3bd42dadae: function AS_Button_bde167617dd84db795b86b3bd42dadae(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAdd");
        ntf.navigate();
    },
    /** onclick defined for btnView **/
    AS_Button_eae8d710628d4a16b329a0695c04cdc9: function AS_Button_eae8d710628d4a16b329a0695c04cdc9(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmView");
        ntf.navigate();
    },
    /** onclick defined for btnExit **/
    AS_Button_d7719f46e31d4c88ac3151007fe61496: function AS_Button_d7719f46e31d4c88ac3151007fe61496(eventobject) {
        var self = this;
        kony.application.exit();
    }
});