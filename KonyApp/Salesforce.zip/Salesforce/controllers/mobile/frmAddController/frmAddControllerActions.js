define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnBack **/
    AS_Button_f9f2ea7802644700bfba6a046fa81d6b: function AS_Button_f9f2ea7802644700bfba6a046fa81d6b(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmMenu");
        ntf.navigate();
    },
    /** onclick defined for btnAdd **/
    AS_Button_i2ceb82c7ac04c2db86fe3d336d5c83f: function AS_Button_i2ceb82c7ac04c2db86fe3d336d5c83f(eventobject) {
        var self = this;
    }
});